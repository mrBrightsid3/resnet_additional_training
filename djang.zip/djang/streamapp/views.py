# streamapp/views.py
from django.shortcuts import render
from django.http.response import StreamingHttpResponse
from .camera import VideoCamera


def gen(camera):
    while True:
        frame, result = camera.get_frame()
        if frame is not None:
            yield (
                b"--frame\r\n"
                b"Content-Type: image/jpeg\r\n\r\n" + frame + b"\r\n\r\n"
                # Добавление результата обработки в ответ
                b"--result\r\n"
                b"Content-Type: text/plain\r\n\r\n" + result.encode() + b"\r\n\r\n"
            )


def video_feed(request):
    return StreamingHttpResponse(
        gen(VideoCamera()), content_type="multipart/x-mixed-replace; boundary=frame"
    )
